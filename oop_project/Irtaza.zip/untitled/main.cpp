//
// Created by rayhan on 4/5/23.
//

#include <iostream>

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
