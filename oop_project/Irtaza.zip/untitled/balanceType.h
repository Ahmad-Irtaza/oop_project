//
// Created by rayhan on 4/5/23.
//
#include<string>

class balanceType
{
    float amount;

public:

    balanceType(float);
    void set(float);
    float get();
    void deposit(float);
    void withdraw(float);
};
#ifndef UNTITLED_BALANCETYPE_H
#define UNTITLED_BALANCETYPE_H

#endif //UNTITLED_BALANCETYPE_H
